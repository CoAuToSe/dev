# clap_generate_fig

Generates [Fig](https://github.com/withfig/autocomplete) completions for [`clap`](https://github.com/clap-rs/clap) based CLIs

<!-- * [Documentation][docs] -->
* [Questions & Discussions](https://github.com/clap-rs/clap/discussions)
* [Website](https://clap.rs/)

<!-- [docs]: https://docs.rs/clap_generate_fig -->
