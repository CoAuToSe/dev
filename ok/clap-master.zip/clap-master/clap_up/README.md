# clap_up

Automatic code upgrader for [clap](https://docs.rs/clap) (using tool [cargo-up](https://github.com/pksunkara/cargo-up))

### Usage

```
cargo install cargo-up --features cli --no-default-features
```

```
cargo up dep clap
```
